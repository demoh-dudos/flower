<?php

namespace app\controllers;

use Symfony\Component\Yaml\Yaml;

class AdminController extends \yii\web\Controller
{
    public function actionIndex()
    {
        if (\Yii::$app->user->isGuest)  return $this->redirect('../site/login');
        if (\Yii::$app->user->identity->is_admin==0) return $this->redirect('../site/login');
        return $this->render('index');
    }

}
